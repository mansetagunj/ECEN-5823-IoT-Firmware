#ifndef INIT_BOARD_H
#define INIT_BOARD_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stdbool.h"

void initBoard(void);

#ifdef __cplusplus
}
#endif

#endif // INIT_BOARD_H
